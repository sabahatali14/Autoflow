import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import TechTicker from './components/TechTicker';
import Services from './components/Services';
import CrmAiDemo from './components/CrmAiDemo';
import Pricing from './components/Pricing';
import Industries from './components/Industries';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 scroll-smooth">
      <Navbar />
      <main>
        <Hero />
        <TechTicker />
        <Services />
        <CrmAiDemo />
        <Pricing />
        <Industries />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;