import React from 'react';
import { PRICING } from '../constants';
import { Check } from 'lucide-react';

const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Transparent Pricing</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Choose a package that fits your stage of growth. No hidden fees.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {PRICING.map((tier, idx) => (
            <div 
              key={idx} 
              className={`relative flex flex-col rounded-2xl border ${tier.recommended ? 'border-brand-500 shadow-2xl scale-105 z-10' : 'border-slate-200 shadow-lg'} bg-white p-8`}
            >
              {tier.recommended && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-brand-600 text-white px-4 py-1 rounded-full text-sm font-bold tracking-wide uppercase">
                  Best Value
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-xl font-bold text-slate-900">{tier.name}</h3>
                <p className="text-sm text-slate-500 mt-2 min-h-[40px]">{tier.description}</p>
              </div>

              <div className="mb-6">
                <span className="text-3xl font-bold text-slate-900">{tier.price}</span>
                {tier.name === "Partner" && <span className="text-slate-500 text-sm font-medium">/month</span>}
              </div>

              <ul className="flex-1 space-y-4 mb-8">
                {tier.features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <Check className="h-5 w-5 text-brand-500 shrink-0 mr-3" />
                    <span className="text-sm text-slate-700">{feature}</span>
                  </li>
                ))}
              </ul>

              <a 
                href="#contact" 
                className={`w-full py-3 px-4 rounded-lg font-semibold text-center transition ${
                  tier.recommended 
                    ? 'bg-brand-600 text-white hover:bg-brand-700 shadow-lg shadow-brand-500/30' 
                    : 'bg-slate-50 text-slate-900 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {tier.cta}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Pricing;