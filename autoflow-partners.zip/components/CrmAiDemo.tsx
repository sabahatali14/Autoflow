import React, { useState } from 'react';
import { Sparkles, ArrowRight, Loader2, Bot } from 'lucide-react';
import { analyzeWorkflow } from '../services/geminiService';
import { WorkflowAuditResponse } from '../types';

const CrmAiDemo: React.FC = () => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<WorkflowAuditResponse | null>(null);
  const [error, setError] = useState('');

  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setLoading(true);
    setError('');
    setResult(null);

    try {
      const data = await analyzeWorkflow(input);
      setResult(data);
    } catch (err) {
      setError("We couldn't process that request right now. Please try again or contact us directly.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="demo" className="py-24 bg-brand-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-100 text-indigo-700 text-xs font-bold uppercase tracking-wide mb-4">
            <Bot className="h-4 w-4" />
            AI Powered
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Free Process Audit
          </h2>
          <p className="text-lg text-slate-600">
            Describe a repetitive task you hate doing (e.g., "I manually move invoices from Microsoft Dynamics 365 to Xero"). 
            <br />Our AI will design an automation strategy for you instantly.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100">
          <div className="p-6 md:p-8">
            <form onSubmit={handleAnalyze} className="relative">
              <label htmlFor="process-input" className="sr-only">Describe your process</label>
              <textarea
                id="process-input"
                rows={4}
                className="w-full p-4 text-slate-700 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-transparent outline-none resize-none transition"
                placeholder="Example: I manually move invoices from Microsoft Dynamics 365 to Xero and have to check them line by line."
                value={input}
                onChange={(e) => setInput(e.target.value)}
              />
              
              <div className="mt-4 flex justify-end items-center">
                <div className="flex items-center gap-4">
                  <button
                    type="submit"
                    disabled={loading || !input}
                    className="flex items-center justify-center px-6 py-3 bg-brand-600 text-white font-medium rounded-lg hover:bg-brand-700 disabled:opacity-50 disabled:cursor-not-allowed transition shadow-md w-full sm:w-auto"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="h-5 w-5 mr-2" />
                        Generate Plan
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>

          {error && (
            <div className="p-4 bg-red-50 text-red-600 text-sm text-center border-t border-red-100">
              {error}
            </div>
          )}

          {result && (
            <div className="bg-slate-900 text-white p-6 md:p-8 animate-fade-in">
              <div className="flex items-start gap-4 mb-6">
                <div className="p-3 bg-brand-600 rounded-lg shrink-0">
                  <Bot className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-1">Automation Strategy</h3>
                  <p className="text-slate-300 text-sm leading-relaxed">{result.analysis}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8 pt-6 border-t border-slate-700">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-brand-400 mb-3">Recommended Tools</h4>
                  <div className="flex flex-wrap gap-2">
                    {result.suggestedTools.map((tool, i) => (
                      <span key={i} className="px-3 py-1 bg-slate-800 rounded-full text-xs font-medium border border-slate-700">
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-brand-400 mb-3">Estimated Impact</h4>
                  <div className="flex items-center gap-2 text-2xl font-bold text-white">
                    {result.estimatedTimeSaved}
                    <span className="text-sm font-normal text-slate-400 mt-1">saved / week</span>
                  </div>
                </div>
              </div>

              <div className="mt-8 text-center flex flex-col sm:flex-row justify-center items-center gap-6">
                 <a href="#contact" className="inline-flex items-center text-sm font-medium text-brand-400 hover:text-brand-300 transition">
                   Let us build this for you <ArrowRight className="ml-1 h-4 w-4" />
                 </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default CrmAiDemo;