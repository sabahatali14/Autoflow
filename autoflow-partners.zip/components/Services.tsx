import React from 'react';
import { SERVICES, OUTCOMES } from '../constants';

const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Core Automation Areas</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            We don't just "connect tools". We engineer outcomes that save you money and time.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
          {SERVICES.map((service, idx) => (
            <div key={idx} className="bg-slate-50 rounded-xl p-6 border border-slate-100 hover:shadow-xl transition duration-300 group">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center mb-6 shadow-sm group-hover:bg-brand-600 transition duration-300">
                <service.icon className="h-6 w-6 text-brand-600 group-hover:text-white transition" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h3>
              <p className="text-slate-600 mb-4 text-sm leading-relaxed">{service.description}</p>
              <ul className="space-y-2">
                {service.examples.map((ex, i) => (
                  <li key={i} className="text-xs font-medium text-slate-500 bg-white px-2 py-1 rounded border border-slate-200 inline-block mr-2 mb-2">
                    {ex}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Outcomes Section */}
        <div id="outcomes" className="bg-slate-900 rounded-3xl p-8 md:p-16 text-white relative overflow-hidden">
           {/* Abstract Decoration */}
           <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-brand-500/20 rounded-full blur-3xl"></div>
           
           <div className="relative z-10">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">We Sell Outcomes, Not Just Workflows</h2>
              <p className="text-slate-400">The technology is the vehicle. The destination is efficiency.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {OUTCOMES.map((outcome, idx) => (
                <div key={idx} className="flex flex-col items-center text-center p-4">
                  <div className="mb-4 p-3 bg-white/10 rounded-full">
                    <outcome.icon className="h-8 w-8 text-brand-400" />
                  </div>
                  <h4 className="text-lg font-bold mb-2">{outcome.title}</h4>
                  <p className="text-sm text-slate-400">{outcome.description}</p>
                </div>
              ))}
            </div>
           </div>
        </div>

      </div>
    </section>
  );
};

export default Services;