import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-brand-100 via-slate-50 to-white opacity-70"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-50 border border-brand-100 text-brand-700 text-sm font-semibold mb-8 animate-fade-in-up">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
          </span>
          Accepting New Partners for Q4
        </div>

        <h1 className="text-4xl md:text-6xl font-bold text-slate-900 tracking-tight mb-6 leading-tight">
          Stop Wasting Time on <br className="hidden md:block" />
          <span className="text-brand-600">Repetitive Work.</span>
        </h1>
        
        <p className="mt-4 text-xl text-slate-600 max-w-2xl mx-auto mb-10 leading-relaxed">
          We help startups and SMEs remove manual work by automating finance, operations, and reporting using secure cloud tools. 
          <span className="block mt-2 font-medium text-slate-800">Don't buy automation. Buy time, accuracy, and scale.</span>
        </p>

        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-16">
          <a 
            href="https://calendly.com/sabahatali9314/30min" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center px-8 py-4 text-base font-medium rounded-lg text-white bg-brand-600 hover:bg-brand-700 shadow-lg shadow-brand-500/30 transition duration-150 ease-in-out"
          >
            Book a Discovery Call
            <ArrowRight className="ml-2 h-5 w-5" />
          </a>
          <a href="#demo" className="inline-flex items-center justify-center px-8 py-4 text-base font-medium rounded-lg text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 transition duration-150 ease-in-out">
            Try AI Workflow Audit
          </a>
        </div>

        <div className="flex flex-wrap justify-center gap-x-8 gap-y-4 text-sm text-slate-500 font-medium">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-green-500" /> No Hiring Required
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-green-500" /> Enterprise Security
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-green-500" /> Custom Workflows
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;