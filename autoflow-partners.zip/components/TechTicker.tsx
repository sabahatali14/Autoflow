import React from 'react';
import { TECH_STACK } from '../constants';

const TechTicker: React.FC = () => {
  return (
    <div className="w-full bg-slate-900 py-10 overflow-hidden relative">
      <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-slate-900 z-10"></div>
      <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-slate-900 z-10"></div>
      
      {/* Changed w-[200%] to w-max to allow content to flow naturally without wrapping/overlapping */}
      <div className="flex w-max animate-marquee">
        {/* First copy */}
        <div className="flex items-center gap-12 px-12">
          {TECH_STACK.map((tech, index) => (
            <span key={`t1-${index}`} className="text-slate-400 font-semibold text-lg whitespace-nowrap hover:text-white transition cursor-default">
              {tech}
            </span>
          ))}
        </div>
        {/* Second copy for seamless loop */}
        <div className="flex items-center gap-12 px-12">
          {TECH_STACK.map((tech, index) => (
            <span key={`t2-${index}`} className="text-slate-400 font-semibold text-lg whitespace-nowrap hover:text-white transition cursor-default">
              {tech}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TechTicker;