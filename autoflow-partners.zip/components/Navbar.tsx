import React, { useState } from 'react';
import { Menu, X, Cpu } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed w-full z-50 bg-white/90 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex-shrink-0 flex items-center gap-2">
            <Cpu className="h-8 w-8 text-brand-600" />
            <span className="font-bold text-xl tracking-tight text-slate-900">AutoFlow<span className="text-brand-600">Partners</span></span>
          </div>
          
          <div className="hidden md:flex space-x-8 items-center">
            <a href="#services" className="text-slate-600 hover:text-brand-600 font-medium transition">Services</a>
            <a href="#outcomes" className="text-slate-600 hover:text-brand-600 font-medium transition">Outcomes</a>
            <a href="#demo" className="text-slate-600 hover:text-brand-600 font-medium transition">AI Audit</a>
            <a href="#pricing" className="text-slate-600 hover:text-brand-600 font-medium transition">Pricing</a>
            <a href="#contact" className="bg-brand-600 text-white px-5 py-2 rounded-full font-medium hover:bg-brand-700 transition shadow-lg shadow-brand-500/30">
              Get Started
            </a>
          </div>

          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-600 hover:text-slate-900">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-b border-slate-100">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a href="#services" className="block px-3 py-2 text-base font-medium text-slate-700 hover:text-brand-600 hover:bg-slate-50 rounded-md">Services</a>
            <a href="#outcomes" className="block px-3 py-2 text-base font-medium text-slate-700 hover:text-brand-600 hover:bg-slate-50 rounded-md">Outcomes</a>
            <a href="#demo" className="block px-3 py-2 text-base font-medium text-slate-700 hover:text-brand-600 hover:bg-slate-50 rounded-md">AI Audit</a>
            <a href="#pricing" className="block px-3 py-2 text-base font-medium text-slate-700 hover:text-brand-600 hover:bg-slate-50 rounded-md">Pricing</a>
            <a href="#contact" className="block px-3 py-2 text-base font-medium text-brand-600 font-bold">Contact Us</a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;