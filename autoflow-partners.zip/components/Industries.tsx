import React from 'react';
import { INDUSTRIES } from '../constants';

const Industries: React.FC = () => {
  return (
    <section className="py-20 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h3 className="text-2xl font-bold text-slate-900 mb-8">Who We Help</h3>
        <div className="flex flex-wrap justify-center gap-3">
            {INDUSTRIES.map((industry, idx) => (
                <span key={idx} className="px-4 py-2 bg-white rounded-full border border-slate-200 text-slate-600 text-sm font-medium shadow-sm">
                    {industry}
                </span>
            ))}
        </div>
      </div>
    </section>
  );
};

export default Industries;