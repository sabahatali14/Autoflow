import React from 'react';
import { Mail, Calendar } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-brand-600 rounded-3xl overflow-hidden shadow-2xl flex flex-col md:flex-row">
          
          <div className="p-10 md:p-12 md:w-1/2 text-white">
            <h2 className="text-3xl font-bold mb-6">Ready to reclaim your time?</h2>
            <p className="text-brand-100 mb-8 text-lg">
              Let's discuss where your bottlenecks are. No sales pressure, just a consultation on what's possible.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/10 rounded-lg">
                    <Mail className="h-6 w-6" />
                </div>
                <div>
                    <p className="text-sm text-brand-200">Email Us</p>
                    <p className="font-semibold">hello@autoflowpartners.com</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/10 rounded-lg">
                    <Calendar className="h-6 w-6" />
                </div>
                <div>
                    <p className="text-sm text-brand-200">Book a slot</p>
                    <a 
                      href="https://calendly.com/sabahatali9314/30min" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="font-semibold hover:text-brand-200 underline transition"
                    >
                      Schedule via Calendly
                    </a>
                </div>
              </div>
            </div>
          </div>

          <div className="p-10 md:p-12 md:w-1/2 bg-slate-50">
            <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Name</label>
                    <input type="text" className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 outline-none" placeholder="Jane Doe" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Email</label>
                    <input type="email" className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 outline-none" placeholder="jane@company.com" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Biggest Pain Point</label>
                    <select className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-brand-500 outline-none">
                        <option>Finance / Invoicing</option>
                        <option>Operational Chaos</option>
                        <option>Sales Follow-ups</option>
                        <option>Reporting & Data</option>
                        <option>Other</option>
                    </select>
                </div>
                <a 
                  href="https://calendly.com/sabahatali9314/30min"
                  target="_blank"
                  rel="noopener noreferrer" 
                  className="block w-full text-center py-3 bg-slate-900 text-white font-bold rounded-lg hover:bg-slate-800 transition"
                >
                    Book Consultation Now
                </a>
            </form>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Contact;