import { 
  Calculator, 
  Cog, 
  BarChart3, 
  Users, 
  Clock, 
  TrendingUp, 
  ShieldCheck, 
  Activity 
} from 'lucide-react';
import { ServiceItem, PricingTier } from './types';

export const TECH_STACK = [
  "Xero", "Oracle", "Microsoft 365", "AWS", "SAP", "HubSpot", "Salesforce", 
  "QuickBooks", "ServiceNow", "JIRA", "Power BI", "Power Automate", 
  "Tableau", "SharePoint", "Dynamics 365", "Sage 50",
  "Google Cloud Console", "WorkflowMax", "Optimizely", "Odoo", "Notion"
];

export const INDUSTRIES = [
  "Construction & Architecture", "Logistics & Transportation", "Healthcare & Vets",
  "Recruitment", "Creative Agencies", "Manufacturing", "Finance & Banking", 
  "Retail & E-commerce", "Government Tech", "Energy & Utilities", "Hospitality"
];

export const SERVICES: ServiceItem[] = [
  {
    title: "Finance & Accounting",
    description: "Eliminate manual data entry and speed up reconciliation.",
    icon: Calculator,
    examples: ["Auto-invoice from CRM", "Bank sync to reports", "Expense approvals via Teams"]
  },
  {
    title: "Operations Automation",
    description: "Streamline onboarding, tasks, and document management.",
    icon: Cog,
    examples: ["Employee onboarding flows", "Email-to-task creation", "Auto-document filing"]
  },
  {
    title: "Sales & CRM",
    description: "Ensure no lead is left behind with automated follow-ups.",
    icon: Users,
    examples: ["Lead capture & enrichment", "Proposal generation", "Deal stage reporting"]
  },
  {
    title: "Reporting & Dashboards",
    description: "Real-time visibility into your business metrics.",
    icon: BarChart3,
    examples: ["Live KPI Dashboards", "Automated weekly PDF reports", "Sales + Finance merging"]
  }
];

export const OUTCOMES = [
  {
    title: "Time Saved",
    description: "Reclaim 10-20 hours per week per employee by removing busy work.",
    icon: Clock
  },
  {
    title: "Scalability",
    description: "Grow your client base without linearly increasing headcount.",
    icon: TrendingUp
  },
  {
    title: "Accuracy",
    description: "Eliminate human error in data entry, invoicing, and reporting.",
    icon: ShieldCheck
  },
  {
    title: "Real-time Visibility",
    description: "Make decisions based on live data, not last month's spreadsheets.",
    icon: Activity
  }
];

export const PRICING: PricingTier[] = [
  {
    name: "Starter",
    price: "$300 - $800",
    description: "Perfect for Solo Founders & Early Startups.",
    features: [
      "1 - 3 Core Automations",
      "Process Operations Focus",
      "Full Documentation",
      "Standard Support",
      "Ideal for: Invoice → Xero → Email"
    ],
    cta: "Start Simple"
  },
  {
    name: "Growth",
    price: "$1,500 - $4,000",
    description: "For SMEs scaling up (20-200 people).",
    features: [
      "5 - 10 Complex Automations",
      "Multi-department Integration",
      "Custom Dashboard Setup",
      "30-Day Intensive Support",
      "Training Session"
    ],
    cta: "Scale Up",
    recommended: true
  },
  {
    name: "Partner",
    price: "$300 - $1,000 /mo",
    description: "Ongoing optimization and monitoring.",
    features: [
      "24/7 Workflow Monitoring",
      "New Automations Monthly",
      "Continuous Optimization",
      "Priority Support Channel",
      "Quarterly Strategy Review"
    ],
    cta: "Partner With Us"
  }
];