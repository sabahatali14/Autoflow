import { GoogleGenAI, Type } from "@google/genai";
import { WorkflowAuditResponse } from "../types";

const apiKey = process.env.API_KEY || '';
// Note: In a real production app, you might want to proxy this through a backend 
// to avoid exposing the key if not using a specific client-side restricted key.
// However, per instructions, we use process.env.API_KEY directly.

const ai = new GoogleGenAI({ apiKey });

export const analyzeWorkflow = async (processDescription: string): Promise<WorkflowAuditResponse> => {
  if (!apiKey) {
    throw new Error("API Key is missing");
  }

  const model = "gemini-2.5-flash";
  
  const systemInstruction = `
    You are an expert Business Process Automation Consultant for AutoFlow Partners.
    Your goal is to analyze a user's manual business process description and suggest an automated solution.
    
    Guidance:
    - Focus on tools like Xero, HubSpot, Slack, Teams, SharePoint, Power Automate, or generic concepts like "CRM" and "Cloud Storage".
    - Keep the tone professional, encouraging, and solution-oriented.
    - Identify the inefficiency and propose a streamlined workflow.
    - Act as if you have access to the AutoFlow Partners knowledge base (represented by internal documentation).
  `;

  const prompt = `
    User's Manual Process: "${processDescription}"
    
    Please provide:
    1. A brief analysis of why this is inefficient.
    2. A suggested automation workflow (step-by-step).
    3. A list of specific tools that could be used.
    4. An estimated time saved per week (make a reasonable guess based on the complexity).
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: { type: Type.STRING },
            suggestedTools: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            workflowSteps: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
            },
            estimatedTimeSaved: { type: Type.STRING }
          },
          required: ["analysis", "suggestedTools", "workflowSteps", "estimatedTimeSaved"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const json = JSON.parse(text);

    return {
        analysis: json.analysis,
        suggestedTools: json.suggestedTools,
        estimatedTimeSaved: json.estimatedTimeSaved,
    };

  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    throw error;
  }
};