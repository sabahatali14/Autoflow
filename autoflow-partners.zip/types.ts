import React from 'react';

export interface PricingTier {
  name: string;
  price: string;
  description: string;
  features: string[];
  cta: string;
  recommended?: boolean;
}

export interface ServiceItem {
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  examples: string[];
}

export interface WorkflowAuditResponse {
  analysis: string;
  suggestedTools: string[];
  estimatedTimeSaved: string;
}